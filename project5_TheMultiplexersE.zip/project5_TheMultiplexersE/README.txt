Project 5: Classify
Team: The Multiplexers
Team Code: E
Team Members:
Diwan Anuj Jitendra, 170070005
Soumya Chatterjee, 170070010
Arnab Jana, 170100082
Mohan Abhyas, 170260032

How to run the code:
1. Open Xilinx ISE and create a new project 
using the standard chip settings used in the lab. 
These are given for your reference in the instructions/ directory.

2. Click 'Add Source' by right-clicking the xc6slx45-2csg324
and import our 3 .vhd files. Make association of the testbench
as 'Simulation'.

3. Click 'New Source' and add a FIFO using IP CORE of Xilinx (please name the fifo as 'fifo') and 
the settings shown in the screenshots in the instructions/ directory of this submission.

4. Simulate the testbench.